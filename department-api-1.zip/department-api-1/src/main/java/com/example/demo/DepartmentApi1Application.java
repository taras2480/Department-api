package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepartmentApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(DepartmentApi1Application.class, args);
	}

}
